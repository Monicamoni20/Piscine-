/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_alphabet.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mjohn <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                i+#+#+#+#+#+   +#+           */
/*   Created: 2025/07/03 15:56:28 by mjohn             #+#    #+#             */
/*   Updated: 2025/07/03 16:09:10 by mjohn            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include<unistd.h>

void	ft_print_alphabet(void)
{
	char	letter;

	letter = 'a';
	while (letter <= 'z')
	{
		write(1, &letter, 1);
		letter ++;
	}
}

int	main(void)
{
	ft_print_alphabet();
	return (0);
}
