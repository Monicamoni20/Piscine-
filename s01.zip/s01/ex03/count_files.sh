find . -type f,d | wc -l
