/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_fibonacci.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mjohn <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/21 12:35:02 by mjohn             #+#    #+#             */
/*   Updated: 2025/07/22 10:40:27 by mjohn            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

int	ft_fibonacci(int index)
{
	if (index < 0)
		return (-1);
	else if (index == 0)
		return (0);
	else if (index == 1)
		return (1);
	else
		return (ft_fibonacci(index -2) + ft_fibonacci(index - 1));
}
/*
int	main(int argc, char **argv)
{
	if (argc == 2)
	{
		printf("%d", ft_fibonacci(atoi(argv[1])));
	}
	return (0);
}*/
