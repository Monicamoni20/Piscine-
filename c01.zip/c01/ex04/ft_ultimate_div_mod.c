/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_div_mod.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mjohn <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/09 11:38:40 by mjohn             #+#    #+#             */
/*   Updated: 2025/07/10 09:39:11 by mjohn            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <stdio.h>

void	ft_ultimate_div_mod(int *a, int *b)
{
	int	x;
	int	y;

	x = *a / *b;
	y = *a % *b;
	*a = x;
	*b = y;
}
/*
int     main(void)
{
	int     a;
	int     b;
	int     *a1;
	int     *b1;
 
	a = 10;
	b = 5;
	a1 = &a;
	b1 = &b;

	ft_ultimate_div_mod(a1, b1);
	printf("%d", a);
	printf("%d", b);
	
	return (0);
}*/
