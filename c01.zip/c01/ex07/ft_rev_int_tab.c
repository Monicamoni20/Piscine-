/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_int_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mjohn <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/08 14:34:05 by mjohn             #+#    #+#             */
/*   Updated: 2025/07/10 09:49:00 by mjohn            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <stdio.h>

void	ft_rev_int_tab(int *tab, int size)
{
	int	n;
	int	b;

	n = size;
	while (n > size / 2)
	{
		b = tab[n - 1];
		tab[n - 1] = tab[size - n];
		tab[size - n] = b;
		--n;
	}
}
/*
int	main(void)
{
	int	vtab[7];
	int	b;

	for(b = 0; b < 7; ++b)
	{
		vtab[b] = b;
	}
	for(b = 0; b < 7; ++b)
        {
                printf("%d ", vtab[b]);
        }
	ft_rev_int_tab(vtab, 7);
	printf("||| ");
	for(b = 0; b < 7; ++b)
	{
		printf("%d ", vtab[b]);
	}
	return (0);
}*/
