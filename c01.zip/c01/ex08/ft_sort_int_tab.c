/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_int_tab.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mjohn <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/08 17:10:31 by mjohn             #+#    #+#             */
/*   Updated: 2025/07/10 09:49:28 by mjohn            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <stdio.h>

void	ft_sort_int_tab(int *tab, int size)
{
	int	n;
	int	i;
	int	j;
	int	temp;

	n = 0;
	while (n < size)
	{
		i = tab[n];
		j = tab[n + 1];
		temp = n;
		while (j <= i && temp != -1)
		{
			i = tab[temp];
			j = tab[temp + 1];
			tab[temp] = j;
			tab[temp + 1] = i;
			--temp;
		}
		++n;
	}
}
/*
int	main(void)
{
	int	n;
	n = 0;
	int	tab [] = {0, -5, -20, 9};
	while (n < 4)
        {
                printf("%d ", tab[n]);
                ++n;
        }
	ft_sort_int_tab(tab, 4);
	n = 0;
	while (n < 4)
	{
		printf("%d ", tab[n]);
		++n;
	}
}*/
