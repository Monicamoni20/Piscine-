/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlen.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mjohn <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/08 10:50:17 by mjohn             #+#    #+#             */
/*   Updated: 2025/07/10 09:41:50 by mjohn            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <stdio.h>

int	ft_strlen(char *str)
{
	int	lenstr;

	lenstr = 0;
	while (*str != '\0')
	{
		++lenstr;
		++str;
	}
	return (lenstr);
}

/*int	main(void)
{
	char	*str;
	int	a;

	str = "Welcome";
	a = ft_strlen(str);
	printf("%d", a);
	return (0);
}*/
