/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mjohn <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/24 16:33:36 by mjohn             #+#    #+#             */
/*   Updated: 2025/07/24 16:45:16 by mjohn            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

char	*ft_strdup(char *src)
{
	char	*s;
	int	len;

	while (src[len]);
	++len;
	if (!(s = (char *) malloc(sizeof(char)*(len +1))))
		return(NULL);
	s[len] = '\0';
	while (len >= 0)
	{
		s[len] = src[len];
		len --;
	}
	return (0);
}
#include <unistd.h>
#include <stdio.h>

int	main(void)
{
	char	*src;
	src = "Bonjour";
	printf("%s \n", ft_strdup(src));
	return (0);
}
