/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mjohn <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/24 16:19:15 by mjohn             #+#    #+#             */
/*   Updated: 2025/07/24 16:27:22 by mjohn            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>

int	ft_atoi(char *str)
{
	int	i;
	int	result;
	int	sign;

	i = 0;
	result = 0;
	sign = 1;
	while (str[i] == ' ' || (str[i] >= 9 && str[i] <= 13))
		i++;
	while (str[i] != '\0' && (str [i] == '-' || str[i] == '+'))
	{
		if (str[i] == '-')
			sign = sign* - 1;
		i++;
	}
	while(str[i] >= '0'&& str[i] <= '9')
	{
		result = result *10 +(str[i] - '0');
		i++;
	}
	return (result * sign);
}
int	main(void)
{
	char	str[] = "\t\n\r\v\f   ---+--+12345b67";
	printf("%d", ft_atoi(str));
	return (0);
}
