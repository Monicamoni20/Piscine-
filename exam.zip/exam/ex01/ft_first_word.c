/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_first_word.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mjohn <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/24 11:45:58 by mjohn             #+#    #+#             */
/*   Updated: 2025/07/24 12:30:18 by mjohn            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
/*
void	ft_first_word(char *str)
{
	int	i;

	i = 0;
	while (str[i] == ' ' || str[i] == '\t' || str[i] == '\n')
		i++;
	while (str[i] != ' ' && str[i] != '\t' && str[i] != '\n' && str[i] != '\0')
		write(1, str[i++], 1);
	write(1, "\n", 1);
}
int	main(int ac, char **av)
{
	if (ac == 2)
	{
		ft_first_word(av[1]);
		return (0);
	}
	else
		write (1, "\n", 1);
	return (0);
}*/

int	ft_putchar (char c)
{
	write (1, &c, 1);
	return (0);
}

int	main(int ac, char **av)
{
	if (ac ==2)
	{
		while(av[1] && (*av[1] == ' ' || *av[1] == '\t'))
			++ av[1];
		while (*av[1] != '\0' && (*av[1] != ' ' && *av[1] != '\t' && *av[1] != '\n'))
			write(1, av[1]++, 1);
	}
	write (1, "\n", 1);	
	return(0);
}
