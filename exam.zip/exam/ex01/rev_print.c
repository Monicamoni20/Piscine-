/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rev_print.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mjohn <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/24 15:19:01 by mjohn             #+#    #+#             */
/*   Updated: 2025/07/24 15:22:59 by mjohn            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar (char c)
{
	write(1, &c, 1);
}
int	ft_strlen(char *s)
{
	int	i;

	i = 0;
	while (s[i])
		i++;
	return (i);
}
int	main(int ac, char **av)
{
	int	len;
	if (ac == 2)
	{
		len = ft_strlen(av[1]);
		while (len --)
			write(1, &av[1][len], 1);
	}
	ft_putchar('\n');
}
