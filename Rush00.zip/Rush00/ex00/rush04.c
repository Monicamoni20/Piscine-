/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush04.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yichzhan <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/05 12:43:57 by yichzhan          #+#    #+#             */
/*   Updated: 2025/07/05 17:32:57 by yichzhan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c);

void	ft_print_line(int x, char start_char, char middle_char, char end_char)
{
	int	i;

	i = 1;
	while (i <= x)
	{
		if (i == 1)
			ft_putchar(start_char);
		else if (i < x)
			ft_putchar(middle_char);
		else if (i == x)
			ft_putchar(end_char);
		i++;
	}
}

void	rush(int x, int y)
{
	int	n;

	n = 1;
	while (n <= y)
	{
		if (n == 1)
			ft_print_line(x, 'A', 'B', 'C');
		else if (n < y)
			ft_print_line(x, 'B', ' ', 'B');
		else if (n == y)
			ft_print_line(x, 'C', 'B', 'A');
		ft_putchar('\n');
		n++;
	}
}		
