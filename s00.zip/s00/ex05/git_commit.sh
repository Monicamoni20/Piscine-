# !/bin/bash
git log -5 --format="%H"
