/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mjohn <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/15 11:26:35 by mjohn             #+#    #+#             */
/*   Updated: 2025/07/16 18:30:19 by mjohn            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putnbr(int nb)
{
	long int	nbr;
	char		i;		

	nbr = nb;
	if (nbr < 0)
	{
		nbr = -nbr;
		write(1, "-", 1);
	}
	if (nbr / 10 > 0)
	{
		ft_putnbr(nbr / 10);
	}
	i = '0' + nbr % 10;
	write(1, &i, 1);
}
/*
int	main(void)
{
	ft_putnbr(15451);
	return (0);
}*/
