/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi_base.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mjohn <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/16 11:16:35 by mjohn             #+#    #+#             */
/*   Updated: 2025/07/16 18:36:23 by mjohn            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_check_base(char *base)
{
	int	i;
	int	j;

	i = 0;
	while (base[i] != '\0')
	{
		if (base[i] == '-' || base[i] == '+' || base[i] == ' '
			|| (base[i] >= 9 && base[i] <= 12))
			return (0);
		j = i + 1;
		while (base[j] != '\0')
		{
			if (base[i] == base[j])
				return (0);
			j++;
		}
		i++;
	}
	if (i < 2)
		return (0);
	return (1);
}

int	ft_basechr(char c, char *base)
{
	int	i;

	i = 0;
	while (base[i] != '\0')
	{
		if (base[i] == c)
			return (i);
		i++;
	}
	return (-1);
}

int	ft_nbr_base(char *str, char *base)
{
	int	size;
	int	n;
	int	i;

	size = 0;
	n = 0;
	i = 0;
	while (base[size] != '\0')
		size++;
	while (ft_basechr(str[i], base) >= 0 && str[i] != '\0')
	{
		if (ft_basechr(str[i + 1], base) < 0 || str[i + 1] == '\0')
			n = n + ft_basechr(str[i], base);
		else
			n = (n + ft_basechr(str[i], base)) * size;
		i++;
	}
	return (n);
}

int	ft_atoi_base(char *str, char *base)
{
	int	i;
	int	nb;
	int	sign;

	i = 0;
	nb = 0;
	sign = 0;
	if (ft_check_base(base) == 0)
		return (0);
	while (str[i] == ' ' || (str[i] >= 9 && str[i] <= 13))
		i++;
	while (str[i] != '\0' && (str[i] == '-' || str[i] == '+'))
	{
		if (str[i] == '-')
			sign++;
		i++;
	}
	nb = ft_nbr_base(&str[i], base);
	return (-1 * (sign % 2) * nb);
}

int	main(void)
{
	printf("%d", ft_atoi_base(" ---+ --+11000", "01"));
	return (0);
}
