/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_base.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mjohn <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/15 16:40:28 by mjohn             #+#    #+#             */
/*   Updated: 2025/07/16 18:34:48 by mjohn            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	ft_check_base(char *base)
{
	int	i;
	int	j;

	i = 0;
	while (base[i] != '\0')
	{
		if (base[i] == '-' || base[i] == '+')
			return (0);
		j = i + 1;
		while (base[j] != '\0')
		{
			if (base[i] == base[j])
				return (0);
			j++;
		}
		i++;
	}
	if (i < 2)
		return (0);
	return (1);
}

void	ft_putnbr_base(int nbr, char *base)
{
	long int	nb;
	int			size;

	nb = nbr;
	if (ft_check_base(base) == 0)
		return ;
	if (nb < 0)
	{
		nb = -nb;
		write(1, "-", 1);
	}
	size = 0;
	while (base[size] != '\0')
		size++;
	if (nb != 0)
	{
		ft_putnbr_base(nb / size, base);
		nb = nb % size;
		write(1, &base[nb], 1);
	}
}
/*
int	main(void)
{
	ft_putnbr_base(24, "01");
	return (0);
}*/
