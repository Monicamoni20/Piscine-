/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_params.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mjohn <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/21 18:13:11 by mjohn             #+#    #+#             */
/*   Updated: 2025/07/21 18:18:37 by mjohn            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putstr(char *s)
{
	int	i;

	i = 0;
	while (s[i])
	{
		write(1, &s[i], 1);
		i++;
	}
}

int	ft_strcmp(char *s1, char *s2)
{
	int	i;

	i = 0;
	if (!s1 && !s2)
		return (0);
	if (!s1)
		return (-1);
	if (!s2)
		return (1);
	while (s1[i] == s2[i] && s1[i])
		i++;
	return (s1[i] - s2[i]);
}

char	*ft_sort(char **agv, int agc, char *last_min)
{
	int		i;
	char	*min;
	char	*tmp;

	i = 1;
	tmp = agv[1];
	min = 0;
	while (i < agc)
	{
		if ((ft_strcmp(tmp, min) <= 0 || !min) && tmp != last_min
			&& ft_strcmp(tmp, last_min) >= 0)
			min = tmp;
		i++;
		tmp = agv[i];
	}
	if (min)
	{
		ft_putstr(min);
		write(1, "\n", 1);
		return (min);
	}
	return (0);
}

int	main(int agc, char **agv)
{
	int		i;
	char	*min;

	i = 1;
	min = ft_sort(agv, agc, 0);
	while (min)
		min = ft_sort(agv, agc, min);
}
