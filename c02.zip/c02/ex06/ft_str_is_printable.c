/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_printable.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mjohn <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/12 16:01:12 by mjohn             #+#    #+#             */
/*   Updated: 2025/07/22 16:51:00 by mjohn            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_str_is_printable(char *str)
{
	int	is_printable;
	int	i;

	is_printable = 0;
	if (!*str)
	{
		return (1);
	}
	i = 0;
	while (str[i])
	{
		if ((32 <= str[i]) && (126 >= str[i]))
		{
			is_printable = 1;
		}
		else
		{
			is_printable = 0;
			return (0);
		}
		i++;
	}
	return (is_printable);
}

int	main(void)
{
	printf("%d", ft_str_is_printable("Welcome"));
	printf("%d", ft_str_is_printable("123/@+"));
	printf("%d", ft_str_is_printable(""));
	printf("%d", ft_str_is_printable("mONI"));
	return (0);
}
