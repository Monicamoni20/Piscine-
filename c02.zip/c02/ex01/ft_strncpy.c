/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mjohn <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/12 14:12:08 by mjohn             #+#    #+#             */
/*   Updated: 2025/07/13 11:49:44 by mjohn            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>

char	*ft_strncpy(char *dest, char *src, unsigned int n)
{
	unsigned int	i;

	i = 0 ;
	while (i < n && src[i] != '\0')
	{
		dest[i] = src[i];
		i++;
	}
	while (i < n)
	{
		dest[i] = '\0';
		i++;
	}
	return (dest);
}

int	main (void)
{
	char	dest[20];
	char	src[] = "Welcome to piscine";
	int	nbr;
	nbr = 7;
	ft_strncpy(dest, src, nbr);
	for(int i =0; i <nbr; i++)
	{
		if(dest[i] =='\0')
		{
			write(1,"/0", 2);
		}
		else
		{
			write(1, &dest[i], 1);
		}
	}
	return (0);
}
