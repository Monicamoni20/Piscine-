/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_numeric.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mjohn <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/12 15:40:11 by mjohn             #+#    #+#             */
/*   Updated: 2025/07/12 18:17:23 by mjohn            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <stdio.h>
//#include <unistd.h>

int	ft_str_is_numeric(char *str)
{
	int	is_only_digit;
	int	i;

	is_only_digit = 0;
	if (!*str)
	{
		return (1);
	}
	i = 0;
	while (str[i])
	{
		if (('0' <= str[i] && '9' >= str[i]))
		{
			is_only_digit = 1;
		}
		else
		{
			is_only_digit = 0;
			return (0);
		}
		i++;
	}
	return (is_only_digit);
}
/*
int	main(void)
{
	printf("%d", ft_str_is_numeric("Welcome"));
	printf("%d", ft_str_is_numeric("123456789"));
	printf("%d", ft_str_is_numeric("Welcome123"));
	printf("%d", ft_str_is_numeric(""));
	return (0);
}*/
