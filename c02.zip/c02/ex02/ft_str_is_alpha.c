/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mjohn <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/12 14:34:30 by mjohn             #+#    #+#             */
/*   Updated: 2025/07/12 18:16:43 by mjohn            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <stdio.h>
//#include <unistd.h>

int	ft_str_is_alpha(char *str)
{
	int	is_only_alpha;
	int	i;

	is_only_alpha = 0;
	if (!*str)
	{
		return (1);
	}
	i = 0;
	while (str[i])
	{
		if (('a' <= str[i] && 'z' >= str[i])
			|| ('A' <= str[i] && 'Z' >= str[i]))
		{
			is_only_alpha = 1;
		}
		else
		{
			is_only_alpha = 0;
			return (0);
		}
		i++;
	}
	return (is_only_alpha);
}
/*
int	main(void)
{
	printf("%d", ft_str_is_alpha(""));
	printf("%d", ft_str_is_alpha("alpha"));
	printf("%d", ft_str_is_alpha("hello world"));
	printf("%d", ft_str_is_alpha("WELCOME"));
	printf("%d", ft_str_is_alpha("Number123"));
	return (0);
i}*/
