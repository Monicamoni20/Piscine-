/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_lowercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mjohn <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/12 15:48:40 by mjohn             #+#    #+#             */
/*   Updated: 2025/07/12 18:17:57 by mjohn            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <stdio.h>

int	ft_str_is_lowercase(char *str)
{
	int	is_only_lowercase;
	int	i;

	is_only_lowercase = 0;
	if (!*str)
	{
		return (1);
	}
	i = 0;
	while (str[i])
	{
		if (('a' <= str[i] && 'z' >= str[i]))
		{
			is_only_lowercase = 1;
		}
		else
		{
			is_only_lowercase = 0;
			return (0);
		}
		i++;
	}
	return (is_only_lowercase);
}
/*
int	main(void)
{
	printf("%d", ft_str_is_lowercase("lowercase"));
	printf("%d", ft_str_is_lowercase("lowercase with space"));
	printf("%d", ft_str_is_lowercase("UPPERCASE"));
	printf("%d", ft_str_is_lowercase("LoWeRuPpEr"));
	printf("%d", ft_str_is_lowercase(""));
	return (0);
}*/
