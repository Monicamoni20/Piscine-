/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strupcase.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mjohn <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/12 16:36:51 by mjohn             #+#    #+#             */
/*   Updated: 2025/07/12 18:19:31 by mjohn            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <stdio.h>
//#include <unistd.h>

char	*ft_strupcase(char *str)
{
	int	i;

	if (!*str)
	{	
		return (str);
	}
	i = 0;
	while (str[i])
	{
		if (('a' <= str[i] && 'z' >= str[i]))
		{
			str[i] = str[i] - 32;
		}
		i++;
	}
	return (str);
}
/*
int	main(void)
{
	char	str[9] ="school 42";
	write(1, ft_strupcase(str), 9);
	return (0); 
}*/
