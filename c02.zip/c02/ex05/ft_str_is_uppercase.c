/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_uppercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mjohn <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/12 15:59:09 by mjohn             #+#    #+#             */
/*   Updated: 2025/07/12 18:18:30 by mjohn            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <stdio.h>

int	ft_str_is_uppercase(char *str)
{
	int	is_only_uppercase;
	int	i;

	is_only_uppercase = 0;
	if (!*str)
	{	
		return (1);
	}
	i = 0;
	while (str[i])
	{
		if (('A' <= str[i] && 'Z' >= str[i]))
		{
			is_only_uppercase = 1;
		}
		else
		{
			is_only_uppercase = 0;
			return (0);
		}
		i++;
	}
	return (is_only_uppercase);
}
/*
int	main(void)
{
	printf("%d", ft_str_is_uppercase("UPPERCASE"));	
	printf("%d", ft_str_is_uppercase("UPPERCASE WITH SPACE"));	
	printf("%d", ft_str_is_uppercase("lowecase"));	
	printf("%d", ft_str_is_uppercase("LOwerUpper"));	
	printf("%d", ft_str_is_uppercase(" "));	
	return (0);
}*/
