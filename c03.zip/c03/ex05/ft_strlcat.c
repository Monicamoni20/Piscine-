/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mjohn <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/13 15:52:44 by mjohn             #+#    #+#             */
/*   Updated: 2025/07/14 15:22:50 by mjohn            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <stdio.h>
//#include <string.h>

unsigned int	ft_strlcat(char *dest, char *src, unsigned int size)
{
	unsigned int	i;
	unsigned int	j;
	unsigned int	k;

	i = 0;
	while (src[i] != '\0')
		i++;
	j = 0;
	while (dest[j] != '\0' && j < size)
		j++;
	k = i + j;
	if (size == j)
		return (k);
	i = 0;
	while (src[i] != '\0' && j < size -1)
	{
		dest[j] = src[i];
		i++;
		j++;
	}
	dest[j] = '\0';
	return (k);
}
/*
int	main(void)
{
	char	dest[50] = "Hello";
	char	*src;
	unsigned int	size;
	size = 3;
	src = "all";
	printf("%u\n", ft_strlcat(dest, src, size));
	printf("%s\n", dest);
}*/
